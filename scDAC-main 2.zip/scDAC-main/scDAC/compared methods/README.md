The code of GLDC and SDCN are provided in https://github.com/TianyiHuang2022/HCHC/tree/main and https://github.com/bdy9527/SDCN/tree/master.
